This readme file explains how the RAW EcoRRAP benthic data was generated. The reference file is 'raw_data_surveys_12.csv'

12 images per EcoRRAP plot were assessed in ReefCloud with 50 points per image. The ReefCloud model was trained with images from 2021, 2022, and 2023, and from various plots (P1-P4).
- Each row in this dataset represents a single image (12 per plot) and the corresponding cover estimates for each class on that image.
- Note that while 2024 data exists in this dataset, no additional training has been performed on these images and estimates of cover are 100% machine derived.

- The EcoRRAP label set used for annotation is included as a separate .xslx file in this package and contains brief explanations of each label which follow the CATAMI classification scheme (EcoRRAP_Community_Composition_Labelset.xlsx).
- 22% of images were annotated manually (only in 2021, 2022, and 2023) while the remaining images were annotated by the ReefCloud model. 

The dataset includes the following surveys: 
352 plots from 2021, 333 plots from 2022, and 325 plots from 2023, and 191 plots from 2024

Due various logistical, imaging, or processing constraints, the following plots are not included in this dataset:
2022
OSHE_BA2S P 2,3,4				
ISKE_BA4S P 1,2,3,4 		 
ONLI_BA1D P 1,2,3,4 		
ONLI_LA1S P 1,2,3,4 		
ONMO_FR2D P 1,2,3,4

2023
ISKE_BA3S P 1,2,3,4
OCCH_BA2S P 4
ONLI_BA1D P 1,4	
TSDU_BA2S P 1,2,3,4
TSDU_BA3S P 1,2,3,4
TSDU_FR1S P 1,2,3,4
TSDU_FR2S P 1,2,3,4
TSDU_LA1S P 1,2,3,4

2024 excludes all reefs where bleaching was present
OCCH_BA2S P 4 (due to imaging constraints)
OSHE all plots
OSLM all plots
ISKE all plots
ONLI all plots
ONMO all plots
---

Important notes on the data:
- The deep and shallow flank sites at Moore Reef (ONMO_FL1D & ONMO_FL1S) were not imaged on the 2022 field trip due to logistical constraints. 
	- Therefore they were imaged on a fieldtrip in February 2023 as well as the planned 2023 time point in October 2023. 
	- In this dataset, the 02/2023 imaging for these sites is considered as part of the 2022 timepoint.

- The majority of images used were selected with a python script that maximised spatial coverage based on the plot's 3D model. 
	- Where less than 12 images were extracted, the remaining images were extracted manually (every 33rd photo). 
	- A record of plots and the number of images per plot that were manually extracted is available, contact Madison Becker (m.becker@aims.gov.au) for more information if required. 

--- EcoRRAP Abbreviations

Cluster Code:
 - OSHE: Offshore Southern, Heron Island Reef
 - OSLM: Offshore Southern, Lady Musgrave
 - ISKE: Inshore Southern, Keppel Islands (Great Keppel, Halfway, Middle, Miall, North Keppel)
 - OCCH: Offshore Central, Chicken Reef
 - OCDA: Offshore Central, Davies Reef
 - OCLB: Offshore Central, Little Broadhurst 
 - ICPA: Inshore Central, Palm Islands (Orpheus, Pelorus)
 - ONLI: Offshore Northern, Lizard Island
 - ONMO: Offshore Northern, Moore Reef
 - TSAU: Torres Strait, Aukane Reef
 - TSDU: Torres Strait, Dungeness Reef
 - TSMA: Torres Strait, Masig Island

Habitats (numbers associated with habitat abbreviation indicate multiple sites of a habitat type within a reef, e.g. BA1 is 'back 1' while BA2 is 'back 2'):
 - BA: back reef
 - FL: flank reef
 - FR: front reef
 - LA: lagoon reef
